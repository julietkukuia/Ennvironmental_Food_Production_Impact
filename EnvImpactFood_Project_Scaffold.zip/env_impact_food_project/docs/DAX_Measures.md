# DAX Measures

> Replace `Food` with your table name after loading the CSV.

**Totals**
```
Total CO2e (kg per kg) = SUM(Food[Total_emissions])

Total CO2e per 1000 kcal = SUM(Food[Greenhouse gas emissions per 1000kcal (kgCO₂eq per 1000kcal)])

Total CO2e per 100g protein = SUM(Food[Greenhouse gas emissions per 100g protein (kgCO₂eq per 100g protein)])
```

**Stage Totals and Shares**
```
CO2e Land Use Change = SUM(Food[Land use change])
CO2e Animal Feed = SUM(Food[Animal Feed])
CO2e Farm = SUM(Food[Farm])
CO2e Processing = SUM(Food[Processing])
CO2e Transport = SUM(Food[Transport])
CO2e Packaging = SUM(Food[Packaging])
CO2e Retail = SUM(Food[Retail])

CO2e Stage Total = [CO2e Land Use Change] + [CO2e Animal Feed] + [CO2e Farm] + [CO2e Processing] + [CO2e Transport] + [CO2e Packaging] + [CO2e Retail]

% Land Use Change = DIVIDE([CO2e Land Use Change], [CO2e Stage Total])
% Animal Feed = DIVIDE([CO2e Animal Feed], [CO2e Stage Total])
% Farm = DIVIDE([CO2e Farm], [CO2e Stage Total])
% Processing = DIVIDE([CO2e Processing], [CO2e Stage Total])
% Transport = DIVIDE([CO2e Transport], [CO2e Stage Total])
% Packaging = DIVIDE([CO2e Packaging], [CO2e Stage Total])
% Retail = DIVIDE([CO2e Retail], [CO2e Stage Total])
```

**Water and Land**
```
Freshwater per kg (L) = SUM(Food[Freshwater withdrawals per kilogram (liters per kilogram)])
Scarcity Water per kg (L) = SUM(Food[Scarcity-weighted water use per kilogram (liters per kilogram)])
Land per kg (m2) = SUM(Food[Land use per kilogram (m² per kilogram)])
Eutrophication per kg (gPO4eq) = SUM(Food[Eutrophying emissions per kilogram (gPO₄eq per kilogram)])
```

**Outlier Flags**
```
CO2e IQR = VAR q1 = PERCENTILEX.INC(ALL(Food), Food[Total_emissions], 0.25)
           VAR q3 = PERCENTILEX.INC(ALL(Food), Food[Total_emissions], 0.75)
           RETURN q3 - q1

High CO2e Outlier = VAR q1 = PERCENTILEX.INC(ALL(Food), Food[Total_emissions], 0.25)
                    VAR q3 = PERCENTILEX.INC(ALL(Food), Food[Total_emissions], 0.75)
                    VAR iqr = q3 - q1
                    RETURN IF(MAX(Food[Total_emissions]) > q3 + 1.5 * iqr, 1, 0)
```
