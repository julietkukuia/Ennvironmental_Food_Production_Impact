# Power BI Build Guide

## 1. Import and Model
- Get Data → Text/CSV → `data/Food_Production_Clean.csv`
- Ensure data types are set:
  - Decimals for emissions and water metrics
  - Text for categorical fields
- Mark `Food product` as the key descriptive field
- Create relationships only if you add lookup tables (for food groups or nutrients)

## 2. Core Measures
- Add measures from `/docs/DAX_Measures.md`

## 3. Report Pages and Visuals
**Overview**
- Cards: Total CO2e, Scarcity Water per kg, Land per kg
- Bar chart: Top 10 foods by CO2e per kg
- Slicers: Food Group, CO2e Impact Class, Water Scarcity Class

**Emissions by Stage**
- 100 percent stacked bar: stage share by Food product
- Line and clustered column: average stage share vs selected food

**Water and Land**
- Scatter: CO2e per kg (x) vs Scarcity Water per kg (y), bubble size = Land per kg, legend = Food Group
- Table: top and bottom 10 water users

**Normalised Footprints**
- Ranks per 1000 kcal and per 100 g protein with toggles using field parameters

**Substitution Scenarios**
- What if parameters to adjust portions of Meat replaced by Pulses & Soy and compute impact deltas

**Data and Methods**
- Text boxes describing data source, units, definitions, and caveats

## 4. Formatting Tips
- Use consistent units in titles
- Add tooltips with definitions and units
- Use conditional formatting to highlight outliers
