# CRISP DM for Environment Impact of Food Production

## Business Understanding
- Objective: Prioritise foods and lifecycle stages for impact reduction while preserving nutrition and affordability
- Stakeholders: Policymakers, producers, retailers, consumers, environmental NGOs

### KPIs
- Total GHG per kg and per kcal
- Scarcity weighted water use per kg
- Land use per kg
- Eutrophication per kg
- Share of emissions by stage

## Data Understanding
- 43 foods, lifecycle emission stages, water and land metrics, normalisations per kcal and per 100 g protein
- Inspect distributions, missingness, extreme values
- Validate that Stage_Sum equals Total_emissions

## Data Preparation
- Rename `Packging` to `Packaging`
- Add `Food Group`, `CO2e Impact Class`, and `Water Scarcity Class`
- Create date stamped data versioning for reproducibility

## Modelling in Power BI
- Measures for total and stage shares
- Normalised KPIs per kcal and per protein
- Outlier flag using IQR on key metrics
- Scenario parameters to simulate dietary shifts within groups

## Evaluation
- Compare relative rankings to prior literature insights
- Sanity checks: stage averages, top emitters, low emitters, and water stress extremes

## Deployment
- Publish PBIX with the following pages:
  1. Overview scorecards
  2. Emissions by Stage
  3. Water and Land Use
  4. Normalised Footprints
  5. Substitution Scenarios
  6. Data and Methods
