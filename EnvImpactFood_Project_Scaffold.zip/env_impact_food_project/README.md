# Environment Impact of Food Production Analysis

**Updated:** 2025-09-04 14:37 UTC

## Objective
Assess the environmental footprint of common food products and identify leverage points for reducing lifecycle impacts with a focus on greenhouse gas emissions, water use, land use, and eutrophication.

## Tools
- **Power BI Desktop** for data modelling, analysis, and interactive dashboards
- **Power Query** for data cleaning and transformation
- **DAX** for measures and KPI logic
- **GitHub** for version control and documentation

## Data
- Source file: `Food_Production_Clean.csv` (derived from the provided dataset)
- Companion `Data_Dictionary.xlsx` defines all fields and units
- Rows represent food items and columns include lifecycle emissions by stage, water metrics, land use, and eutrophication

## CRISP DM Summary
1. **Business Understanding**: Identify high impact foods and stages to guide policy and consumer choices
2. **Data Understanding**: Explore distributions and data quality across 43 foods and 23 plus derived columns
3. **Data Preparation**: Fix typos, derive groups, create impact classes, validate totals
4. **Modelling**: Create DAX measures to aggregate by food group and normalise per energy or protein
5. **Evaluation**: Benchmark against known results and inspect outliers
6. **Deployment**: Publish a Power BI report with parameterised slicers and a narrative page

## Business Questions
1. Which foods contribute most to lifecycle GHG emissions per kilogram
2. What is the stage wise breakdown of emissions for each food and which stages dominate on average
3. Which foods have the highest freshwater withdrawals and scarcity weighted water use per kilogram
4. How do rankings change when normalised per 1000 kcal and per 100 g protein
5. Which food groups offer the largest impact reductions if consumers substitute within group
6. Which items are outliers with simultaneously high carbon and water footprints
7. What low impact baskets can meet nutritional goals while minimising footprints

## Quick Highlights
**Top 5 by GHG per kg**  
     Food product  Total_emissions
 Beef (beef herd)             59.6
    Lamb & Mutton             24.5
           Cheese             21.2
Beef (dairy herd)             21.1
   Dark Chocolate             18.7

**Lowest 5 by GHG per kg**  
   Food product  Total_emissions
           Nuts              0.2
 Onions & Leeks              0.3
   Citrus Fruit              0.3
Root Vegetables              0.3
       Potatoes              0.3

## Repository Structure
```
/data
  Food_Production_Clean.csv
  Data_Dictionary.xlsx
/docs
  CRISP_DM.md
  PowerBI_Build_Guide.md
  DAX_Measures.md
/presentation
  Project_Summary.pptx
README.md
```

## How to Use
1. Import `data/Food_Production_Clean.csv` into Power BI
2. Follow `/docs/PowerBI_Build_Guide.md` to build the model and visuals
3. Validate DAX using `/docs/DAX_Measures.md`
4. Publish the report and link it in this README

